# Semantic Elements

### Objective:
Understand the importance of semantic tags like <article>, <section>, <nav>, and <aside>.

### Description: 
students have to structure a news website using semantic elements.