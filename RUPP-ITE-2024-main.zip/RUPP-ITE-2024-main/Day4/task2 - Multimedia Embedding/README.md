# Task 2: Multimedia Embedding
### Objective: 
Practice embedding multimedia elements using HTML5.

### Description: 
Students have to create a webpage that includes an image, a video, and audio.

