# Task 5: Canvas Drawing

### Objective: 
Introduce the HTML5 <canvas> element for 2D graphics.
### Description: 
Students have to draw a rectangle and circle on a canvas using JavaScript.

