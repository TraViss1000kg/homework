# Tasks

## Task 1: Embed a Video and an Audio Clip into the Webpage

**Prompt Example:**

"Create a section in your webpage that embeds a YouTube video related to your favorite hobby and an audio file of your choice."

## Task 2: Add Custom Controls to the Media Elements

**Prompt Example:**

"Enhance the media section by adding custom controls for the video and audio files, such as play, pause, and volume control."
